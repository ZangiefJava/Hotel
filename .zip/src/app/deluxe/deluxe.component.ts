import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deluxe',
  templateUrl: './deluxe.component.html',
  styleUrls: ['./deluxe.component.css']
})
export class DeluxeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  prenota(){}
}
