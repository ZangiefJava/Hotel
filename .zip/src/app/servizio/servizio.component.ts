import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servizio',
  templateUrl: './servizio.component.html',
  styleUrls: ['./servizio.component.css']
})
export class ServizioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
