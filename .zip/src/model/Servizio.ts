export class Servizio {
    constructor(
        public id: number,
        public descrizione?: string,
        public costo?: number
    ) { }
}