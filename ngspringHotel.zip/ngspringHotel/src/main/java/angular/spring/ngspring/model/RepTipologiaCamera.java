package angular.spring.ngspring.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RepTipologiaCamera extends JpaRepository<TipologiaCamera, Long>
{
     
}
