package angular.spring.ngspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NgspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
